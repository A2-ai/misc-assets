library(testthat)
library(vaplot)

test_check("vaplot")
