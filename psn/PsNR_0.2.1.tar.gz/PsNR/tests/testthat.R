library(testthat)
library(PsNR)
test_check("PsNR")